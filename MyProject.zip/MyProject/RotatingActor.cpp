#include "RotatingActor.h"
#include "MovingActor.h"
#include "EngineUtils.h"

// Sets default values
ARotatingActor::ARotatingActor()
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

}

// Called when the game starts or when spawned
void ARotatingActor::BeginPlay()
{
	Super::BeginPlay();
	FRotator Rot = GetActorRotation();
	Rot.Pitch = 90;
	SetActorRotation(Rot);

}

// Called every frame
void ARotatingActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}
AMovingActor::AMovingActor()
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
}

// Called when the game starts or when spawned
void AMovingActor::BeginPlay()
{
	Super::BeginPlay();

}

// Called every frame
void AMovingActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	for (TActorIterator<AMovingActor> Itr(AActor::GetWorld()); Itr; ++Itr)
		Itr->SetActorHiddenInGame(true);
}


